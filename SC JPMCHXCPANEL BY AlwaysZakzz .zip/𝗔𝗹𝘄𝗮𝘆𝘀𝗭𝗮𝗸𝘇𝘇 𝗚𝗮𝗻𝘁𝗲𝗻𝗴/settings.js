/* 

=========================================================================

  HELO BG 🦅
 CREDIT : 𝐴𝑙𝑤𝑎𝑦𝑠𝑍𝑎𝑘𝑧𝑧 𝑂𝑓𝑓𝑖𝑐𝑖𝑎𝑙
 WA AlwaysZakzz : 6285817068074   

=========================================================================

*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6285817068074'
global.versi = version
global.namaOwner = "AlwaysZakzz-Botz"
global.packname = 'AlwaysZakzz-Botz'
global.botname = '𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳𝐗𝐉𝐩𝐦𝐜𝐡𝐗𝐂𝐩𝐚𝐧𝐞𝐥'
global.botname2 = '𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳𝐗𝐉𝐩𝐦𝐜𝐡𝐗𝐂𝐩𝐚𝐧𝐞𝐥'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6285817068074"
global.linkGrup = "https://chat.whatsapp.com/BoDRwDQeAC6I9RsQjI09gu"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 4000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VarGepU1dAw1U76h3S1k"
global.idSaluran = "120363344401749353@newsletter"
global.namaSaluran = "ZakzzHosting Official¹"

global.merchantIdOrderKuota = "-"
global.apiOrderKuota = "-"
global.qrisOrderKuota = "-"

// Settings Api Digital Ocean
global.apiDigitalOcean = "-"

// Settings Api Digital Ocean
global.apiSimpelBot = "new2025"


// Settings All Payment
global.dana = "085693453463"
global.ovo = "-"
global.gopay = "085210835836"

// Settings Image Url
global.image = {
menu: "https://files.catbox.moe/1039m7.jpg", 
reply: "https://files.catbox.moe/1039m7.jpg", 
logo: "https://files.catbox.moe/itepcz.jpg", 
dana: "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg", 
ovo: "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg", 
gopay: "https://img100.pixhost.to/images/667/540083275_skyzopedia.jpg", 
qris: "https://files.catbox.moe/9j1vtj.jpg"
}

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = ""
global.apikey = "" //ptla
global.capikey = "" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = ""
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc

// Settings Api Subdomain
global.subdomain = {
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"dannxp-host.my.id": {

"zone": "ffdd33de5e1eb1db01e4bca8e0ab06ae", 

"apitoken": "LeKb3YO7EWxkBho75oRl9s2gicW7Wlr-mz7h6sX8"

}
}

// Message Command 
global.mess = {
	owner: " *ᴋʜᴜsᴜs ᴏᴡɴᴇʀ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ ʙᴀɴɢ ᴀʟᴡᴀʏꜱᴢᴀᴋᴢᴢ",
	admin: " *ᴋʜᴜsᴜs ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ʙᴀɴɢ ᴀʟᴡᴀʏꜱᴢᴀᴋᴢᴢ",
	botAdmin: " *ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ",
	group: " *ᴋʜᴜsᴜs ɢʀᴜᴘ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴅɪ ɢʀᴏᴜᴘ",
	private: " *ᴋʜᴜsᴜs ᴄʜᴀᴛ ᴘʀɪᴠᴀᴛᴇ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ",
	prem: " *ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ",
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})